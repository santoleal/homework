from setuptools import setup

setup(

    name = "paquete_preentrega2",
    version = "1.0",
    description = "Pre-entrega 2",
    author = "Felipe Leal Arancibia",
    author_email = "",
    packages = ["paquete_preentrega2"]
)