# Pre-entrega 1 y 2, mezcladas. 
# Saludos y gracias.
# Felipe Leal A.

from menu import Menu



sesion = Menu()
sesion.menu()

